//////////////////////////////////////////////////////////
//							//
// File:		DTMercs.VOL			//
// Version:		1.0				//
// Author: 		THZ*BlackjackDTM (Ryan Snook)	//					
// THZ Address:		http://thz.tsx.org		//
// Author Home Page:	http://snooknet.tsx.org	 	//
// E-mail:		ryan.traci@gte.net		//
//							//
// DTM Web Page:	http://www.lycaon.com/dtm	//
//							//
//////////////////////////////////////////////////////////

Install -
To install, drop in the Tribes\Base\Skins folder.


Thanks -
Thanks to Dynamix and everybody who loves to play Tribes and
 the DTM for giving Teamplayers a home.


Visit -
http://www.wheres.com/etc/icqskins for Tribes themed Icq Skins.


Credits -
I made the emblem#.bmp's and flag.bmp from the logo on the 
 home page for DTM.  The male skins and heavy were made by
 Knight and the female skins by Hunter.